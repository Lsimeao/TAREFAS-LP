
package batepapo;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class Servidor extends javax.swing.JFrame {
    
    ServerSocket ss;
    Socket cliente;
    DataInputStream in;
    DataOutputStream out;

    public Servidor() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        txtMSG = new javax.swing.JTextField();
        btENVIAR = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        AREA = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btENVIAR.setText("ENVIAR");
        btENVIAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btENVIARActionPerformed(evt);
            }
        });

        AREA.setColumns(20);
        AREA.setRows(5);
        jScrollPane1.setViewportView(AREA);

        jLabel1.setFont(new java.awt.Font("Noto Sans", 3, 18)); // NOI18N
        jLabel1.setText("SERVIDOR");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(txtMSG, javax.swing.GroupLayout.PREFERRED_SIZE, 383, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 33, Short.MAX_VALUE)
                        .addComponent(btENVIAR)))
                .addGap(30, 30, 30))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(221, 221, 221))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 48, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 245, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMSG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btENVIAR))
                .addGap(45, 45, 45))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btENVIARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btENVIARActionPerformed

        try {
            out.writeUTF(txtMSG.getText());
            AREA.append(txtMSG.getText());
            txtMSG.setText("");
            
        } catch (Exception e) {
            AREA.append("Falha " +e+ "\n");
        }










        // TODO add your handling code here:
    }//GEN-LAST:event_btENVIARActionPerformed

    public void executar(){
        try {
            ss = new ServerSocket(8080);
            AREA.append("Servidor está executando na porta 8080\n");
            cliente = ss.accept();
            InetAddress ip = cliente.getInetAddress();
            AREA.append("host " + ip + "conectado\n");
            while(true){
                in = new DataInputStream(cliente.getInputStream());
                out = new DataOutputStream(cliente.getOutputStream());
                AREA.append(in.readUTF() +"\n");
            }
            
        } catch (Exception e) {
            AREA.append("Falha " + e + "\n");
            
        }
    }
    
    
    public static void main(String args[]) {
         
        Servidor obj = new Servidor();
        obj.setVisible(true);
        obj.executar();
       
        
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AREA;
    private javax.swing.JButton btENVIAR;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtMSG;
    // End of variables declaration//GEN-END:variables
}
