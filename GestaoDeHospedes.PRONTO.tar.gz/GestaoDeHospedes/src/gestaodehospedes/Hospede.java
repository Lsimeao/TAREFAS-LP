
package gestaodehospedes;


public class Hospede {
    private String Nome,Email;
    private String CPF,Telefone;
    private int posicao;
   
    public Hospede(String Nome, String Email, String CPF, String Telefone) {
        //this.posicao = posicao;
        this.Nome = Nome;
        this.Email = Email;
        this.CPF = CPF;
        this.Telefone = Telefone;
    }

    public int getPosicao() {
        return posicao;
    }

    public void setPosicao(int posicao) {
        this.posicao = posicao;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String Telefone) {
        this.Telefone = Telefone;
    }

    @Override
    public String toString() {
        return "Hospedagem{" + "Nome=" + Nome + ", Email=" + Email + ", CPF=" + CPF + ", Telefone=" + Telefone + '}';
    }
    
}
