package gestaodehospedes;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaDeCadastro extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TelaDeCadastro.class.getName());
    ArrayList<Hospede> lista = new ArrayList<>();
    DefaultTableModel dtm;
    int posicao;

    public TelaDeCadastro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        txtCPF = new javax.swing.JTextField();
        txtEmail = new javax.swing.JTextField();
        txtFone = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblCAD = new javax.swing.JTable();
        btADD = new javax.swing.JButton();
        btDEL = new javax.swing.JButton();
        btEDIT = new javax.swing.JButton();
        btCLEAR = new javax.swing.JButton();
        btCLOSE = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Nome:");

        jLabel2.setText("CPF:");

        jLabel3.setText("Email:");

        jLabel4.setText("Telefone:");

        tblCAD.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Nome", "CPF", "Email", "Telefone"
            }
        ));
        tblCAD.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblCADMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblCAD);

        btADD.setText("ADD");
        btADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btADDActionPerformed(evt);
            }
        });

        btDEL.setText("DEL");
        btDEL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDELActionPerformed(evt);
            }
        });

        btEDIT.setText("EDIT");
        btEDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEDITActionPerformed(evt);
            }
        });

        btCLEAR.setText("CLEAR");
        btCLEAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCLEARActionPerformed(evt);
            }
        });

        btCLOSE.setText("CLOSE");
        btCLOSE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCLOSEActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(90, 90, 90)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(48, 48, 48)
                        .addComponent(btADD)
                        .addGap(30, 30, 30)
                        .addComponent(btDEL)
                        .addGap(41, 41, 41)
                        .addComponent(btEDIT)
                        .addGap(44, 44, 44)
                        .addComponent(btCLEAR)
                        .addGap(35, 35, 35)
                        .addComponent(btCLOSE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 620, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addGap(52, 52, 52)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNome)
                            .addComponent(txtCPF, javax.swing.GroupLayout.DEFAULT_SIZE, 373, Short.MAX_VALUE)
                            .addComponent(txtEmail)
                            .addComponent(txtFone))))
                .addContainerGap(86, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(82, 82, 82)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCPF, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtFone, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btADD)
                    .addComponent(btDEL)
                    .addComponent(btEDIT)
                    .addComponent(btCLEAR)
                    .addComponent(btCLOSE))
                .addContainerGap(68, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btEDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEDITActionPerformed
        if (tblCAD.getSelectedRow() != -1) {
            String Nome, Email, Telefone;
            Nome = txtNome.getText();
            Email = txtEmail.getText();
            //CPF = txtCPF.getText();
            Telefone = txtFone.getText();
            String CPF = tblCAD.getValueAt(tblCAD.getSelectedRow(), 1).toString();
            Hospede h = new Hospede(Nome, Email, CPF, Telefone);
            Operacoes op = new Operacoes();
            if (op.editar(h, CPF, lista)) {
                showHospede();
                limpar();
            }else{
                JOptionPane.showMessageDialog(rootPane, "falha na edição, tente novamente");
            }
        }else{
            JOptionPane.showMessageDialog(rootPane, "clique na linha que deseja editar");
        }


    }//GEN-LAST:event_btEDITActionPerformed

    private void btCLOSEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCLOSEActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btCLOSEActionPerformed

    private void btADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btADDActionPerformed
        String Nome, Email, CPF, Telefone;
        Nome = txtNome.getText();
        Email = txtEmail.getText();
        CPF = txtCPF.getText();
        Telefone = txtFone.getText();
        Hospede h = new Hospede(Nome, Email, CPF, Telefone);
        Operacoes op = new Operacoes();

        if (op.adicionar(h, lista)) {
            showHospede();
            limpar();
        } else {
            JOptionPane.showMessageDialog(rootPane, "falha!");
        }

    }//GEN-LAST:event_btADDActionPerformed

    private void btCLEARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCLEARActionPerformed
        limpar();

    }//GEN-LAST:event_btCLEARActionPerformed

    private void btDELActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDELActionPerformed
        if (tblCAD.getSelectedRow() != -1) {
            String CPF = tblCAD.getValueAt(tblCAD.getSelectedRow(), 1).toString();
            Operacoes op = new Operacoes();
            if (op.deletar(CPF, lista)) {
                dtm.removeRow(tblCAD.getSelectedRow());

            } else {
                JOptionPane.showMessageDialog(rootPane, "erro ao excluir cadastro");
            }

        } else {
            JOptionPane.showMessageDialog(rootPane, "é preciso clicar em um hospede");
        }
        showHospede();
        limpar();

    }//GEN-LAST:event_btDELActionPerformed

    private void tblCADMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblCADMouseClicked
        if(tblCAD.getSelectedRow()!= -1){
            txtCPF.setText(tblCAD.getValueAt(tblCAD.getSelectedRow(),1).toString());
            txtEmail.setText(tblCAD.getValueAt(tblCAD.getSelectedRow(),2).toString());
            txtNome.setText(tblCAD.getValueAt(tblCAD.getSelectedRow(),0).toString());
            txtFone.setText(tblCAD.getValueAt(tblCAD.getSelectedRow(),3).toString());
        }
        
        

    }//GEN-LAST:event_tblCADMouseClicked
    private void limpar() {
        txtNome.setText("");
        txtCPF.setText("");
        txtEmail.setText("");
        txtFone.setText("");
    }

    private void showHospede() {
        dtm = (DefaultTableModel) tblCAD.getModel();
        dtm.setNumRows(0);
        for (int i = 0; i < lista.size(); i++) {
            dtm.addRow(new Object[]{
                lista.get(i).getNome(),
                lista.get(i).getCPF(),
                lista.get(i).getEmail(),
                lista.get(i).getTelefone()

            });
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(() -> new TelaDeCadastro().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btADD;
    private javax.swing.JButton btCLEAR;
    private javax.swing.JButton btCLOSE;
    private javax.swing.JButton btDEL;
    private javax.swing.JButton btEDIT;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblCAD;
    private javax.swing.JTextField txtCPF;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFone;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
