
package gestaodehospedes;

import java.util.ArrayList;

public class Operacoes {
    public boolean adicionar (Hospede h, ArrayList<Hospede>lista){
        return lista.add(h);
        
    }
    public boolean deletar(String cpf,ArrayList<Hospede>lista){
        boolean deletado = false;
        for (int i = 0; i < lista.size(); i++) {
           if(lista.get(i).getCPF().equals(cpf)){
               lista.remove(i);
               deletado=true;
               break;
           } 
        }
        return deletado;
    }
    public boolean editar(Hospede h,String cpf,ArrayList<Hospede>lista){
        boolean editado = false;
        for (int i = 0; i < lista.size(); i++) {
            if(lista.get(i).getCPF().equals(cpf)){
                lista.set(i, h);
                editado = true;
                break;
            }
        }
        return editado;
    }
}

