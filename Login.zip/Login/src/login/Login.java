package login;

import java.util.Scanner;


public class Login {

    
    public static void main(String[] args) {
        
        String login = null;
        int senha = 0;
        
        Scanner input = new Scanner(System.in);
        
        System.out.println("Login...");
        login = input.next();
        
        System.out.println("Senha...");
        senha = input.nextInt();
        
        if (login.equals("IFBA") && senha == 123456){
            System.out.println("ACESSO LIBERADO");
        }else{
            System.out.println("Acesso negado");
        
        
        }
        
    }
    
}
