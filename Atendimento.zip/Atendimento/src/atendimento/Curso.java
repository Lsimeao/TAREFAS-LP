package atendimento;

public class Curso {

    private int codigo;
    private String nome;

    //método construtor cadastram as variaveis (geralmente tem o mesmo nome da classe)e nao tem tipo de dado de retorno
    public Curso(int codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }
//ele pega o valor do metodo codigo com o get
    public int getCodigo() {
        return codigo;
    }
//ele coloca o valor pego pelo get e coloca no metodo codigo com o set
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    @Override
    public String toString() {
        return "Curso{" + "codigo=" + codigo + ", nome=" + nome + '}';
    }

    
    
}
