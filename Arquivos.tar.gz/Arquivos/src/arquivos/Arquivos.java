
package arquivos;
import java.io.*;

public class Arquivos {
    
    
    public static void main(String[] args) {
        try {
            File arq = new File("/home/aluno/Dowloads");
            
            if(arq.isFile()){
                System.out.println("É ARQUIVO");
                System.out.println("Nome: " +arq.getName());
                System.out.println("Tamanho: " +arq.length());
                System.out.println("Caminho: " +arq.getPath());
                
            }else if(arq.isDirectory()){
                System.out.println("É diretório/pasta");
                System.out.println("Conteudo de Dir. Aluno: ");
                String[] vet = arq.list();
                for (String elemento : vet) {
                    System.out.println(elemento);
                    
                }
            }
            
        } catch (Exception e) {
            System.out.println("Falha " + e);
        }

    }//fechamento do método
    
}//fechamento da classe
