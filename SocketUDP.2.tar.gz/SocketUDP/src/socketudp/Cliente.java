
package socketudp;
import java.net.*;
import java.net.DatagramSocket;
import java.util.Arrays;


public class Cliente {
    public static void main(String[] args) {
        try {
            DatagramSocket dsCliente = new DatagramSocket();
            InetAddress ip = InetAddress.getByName("localhost");
            
            byte[] recDados = new byte[512];
            byte[] envDados = new byte[512];
            
            String msg = "oi,hj tem baile da gaiola?";
            envDados = msg.getBytes();
            //montando pacote a ser enviado
            DatagramPacket dpED = new DatagramPacket(envDados,envDados.length,ip, 8080);//montando pacote para envio de dados
            dsCliente.send(dpED);//cliente envia pacote

            DatagramPacket dpRD = new DatagramPacket(recDados,recDados.length);
            dsCliente.receive(dpRD);//recebendo os dados que vieram do servidor
            
            String msgM = new String(dpRD.getData());
            System.out.println(Arrays.toString(dpRD.getData()));
            dsCliente.close();
            
            
            
        } catch (Exception e) {
            System.out.println("Exceção: " +e);
        }
        
    }//fechamento do main
}//fechamneto da classe
