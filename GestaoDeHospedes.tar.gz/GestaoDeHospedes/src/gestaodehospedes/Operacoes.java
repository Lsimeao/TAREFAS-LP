
package gestaodehospedes;

import java.util.ArrayList;

public class Operacoes {
    public boolean adicionar (Hospede h, ArrayList<Hospede>lista){
        return lista.add(h);
        
    }
}
