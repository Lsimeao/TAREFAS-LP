package danteejean;

public class Vilao extends Personagem{
    private int tempodeprisao;

    public Vilao(int tempodeprisao, String nome, String nomeReal) {
        super(nome, nomeReal);
        this.tempodeprisao = tempodeprisao;
    }
    
}
