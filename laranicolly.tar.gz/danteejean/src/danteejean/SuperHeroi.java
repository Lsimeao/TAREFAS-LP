package danteejean;

public class SuperHeroi extends Personagem {

    public SuperHeroi(String nome, String nomeReal) {
        super(nome, nomeReal);
    }

@Override
    public int getPoderTotal() {
        int soma = (int) (super.getPoderTotal() * 1.1);
        return soma;
    }


}
