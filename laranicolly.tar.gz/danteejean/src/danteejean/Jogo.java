
package danteejean;

public class Jogo {


    public static void main(String[] args) {
        SuperHeroi flash = new SuperHeroi("Flash", "Barry Allen");
        Vilao luthor = new Vilao(10, "Lex Luthor", "Lex Luthor");
        
        Superpoder sp1 = new Superpoder("Velocidade", 5);
        Superpoder sp2 = new Superpoder("Força", 5);
        Superpoder sp3 = new Superpoder("Voar", 3);
        Superpoder sp4 = new Superpoder("Raio x", 4);
        Superpoder sp5 = new Superpoder("Sopro congelante", 4);
        Superpoder sp6 = new Superpoder("Mente aguçada", 5);


        flash.adicionaSuperpoder(sp1);
        luthor.adicionaSuperpoder(sp6);
        
        Confronto luta1 = new Confronto ();
        
        switch (luta1.executar(flash, luthor)) {
            case 1:
                System.out.println("O Vencedor foi o Flash");
                break;
            case 2:
                System.out.println("O Vencedor foi o Luthor");
                break;
            default:
                System.out.println("Houve um empate");
                break;
        }
    }
    
}
