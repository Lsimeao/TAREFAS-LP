
package herança;

import java.util.Scanner;


public class Principal {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Digite seu nome: ");
        String nomeP = sc.next();
        System.out.println("Digiteseu cpf: ");
        String cpfP = sc.next();
        Pessoa p1 = new Pessoa(nomeP, cpfP);
        System.out.println(p1.toString());
        
        
        
        System.out.println("Digite o nome do funcionario: ");
        String nomeF = sc.next();
        System.out.println("Digite o cpf do funcionario: ");
        String cpfF = sc.next();
        System.out.println("Digite o salario do funcionario: ");
        double salario = sc.nextDouble();
        Funcionario f1 = new Funcionario(salario, nomeF, cpfF);
        System.out.println(f1.toString());
         
        
    }
    
}
