
package herança;


public class DemoAuto {

    
    public static void main(String[] args) {

    }
    
}
