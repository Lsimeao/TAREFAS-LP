
package herança;


public class AutomovelLuxo extends AutomovelBasico{
    boolean direcaoHidraulica, cambioAutomatico, travasEletricas;

    public AutomovelLuxo(boolean direcaoHidraulica, boolean cambioAutomatico, boolean travasEletricas, boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int tipoDeCombustivel) {
        super(retrovisorPassageiro, limpadorTraseiro, radio, modelo, cor, tipoDeCombustivel);
        this.direcaoHidraulica = direcaoHidraulica;
        this.cambioAutomatico = cambioAutomatico;
        this.travasEletricas = travasEletricas;
    }

    public AutomovelLuxo(boolean direcaoHidraulica, boolean cambioAutomatico, boolean travasEletricas, String modelo, String cor, int tipoDeCombustivel) {
        super(modelo, cor, tipoDeCombustivel);
        this.direcaoHidraulica = true;
        this.cambioAutomatico = true;
        this.travasEletricas = true;
    }

    

    
    
}
