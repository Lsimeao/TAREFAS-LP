
package herança;


public class AutomovelBasico extends Automovel{
    boolean retrovisorPassageiro, limpadorTraseiro, radio;

    public AutomovelBasico(boolean retrovisorPassageiro, boolean limpadorTraseiro, boolean radio, String modelo, String cor, int tipoDeCombustivel) {
        super(modelo, cor, tipoDeCombustivel);
        this.retrovisorPassageiro = retrovisorPassageiro;
        this.limpadorTraseiro = limpadorTraseiro;
        this.radio = radio;
    }

    public AutomovelBasico(String modelo, String cor, int tipoDeCombustivel) {
        super(modelo, cor, tipoDeCombustivel);
        retrovisorPassageiro = true;
        limpadorTraseiro = true;
        radio = true;
        
    }
    
    @Override
    public double quantoCusta(){
        double preço = super.quantoCusta();
        
        if(retrovisorPassageiro){
            preço+= 280;
        }
        if(limpadorTraseiro){
            preço+= 190;
        }
        if(radio){
            preço+= 320;
        }
        return preço;
    }
}
