
package socketudp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;


public class TelaServidor extends javax.swing.JFrame {
    DatagramSocket ds;
    DatagramPacket dp;
     byte[] recDados;
     byte[] envDados;
    InetAddress endIp; 
    int porta;
  

    
    public TelaServidor() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        AREA = new javax.swing.JTextArea();
        txtMsg = new javax.swing.JTextField();
        btENVIAR = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        AREA.setColumns(20);
        AREA.setRows(5);
        jScrollPane1.setViewportView(AREA);

        btENVIAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btENVIARActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 18)); // NOI18N
        jLabel1.setText("SERVIDOR");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(141, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(237, 237, 237))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(txtMsg)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btENVIAR))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(98, 98, 98))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(39, 39, 39)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 246, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMsg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btENVIAR, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(60, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btENVIARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btENVIARActionPerformed
        try {
            String Msg = txtMsg.getText();
            envDados = new byte[64];
            envDados = Msg.getBytes();
            dp = new DatagramPacket(envDados, envDados.length, endIp, porta);
            ds.send(dp);
        } catch (Exception e) {
            AREA.append("Erro ao enviar a mensagem" + e + "/n");
        }

        // TODO add your handling code here:
    }//GEN-LAST:event_btENVIARActionPerformed

    
    public void executar(){
        
        try {
            ds = new DatagramSocket(8080);
            AREA.append("Servidor Operando na porta 8080/n");
            
            while(true){
                recDados = new byte[64];
                dp = new DatagramPacket(recDados, recDados.length);
                ds.receive(dp);
                String Msg = new String (dp.getData());
                endIp = dp.getAddress();
                int porta = dp.getPort();
                
                AREA.append(Msg+"/n");
            }
        } catch (Exception e) {
            AREA.append("Erro" + e + "/n");
            
        }
    }
    
    
    public static void main(String args[]) {
        TelaServidor ts = new TelaServidor();
        ts.setVisible(true);
        java.awt.EventQueue.invokeLater(() -> new TelaServidor().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea AREA;
    private javax.swing.JButton btENVIAR;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtMsg;
    // End of variables declaration//GEN-END:variables
}
