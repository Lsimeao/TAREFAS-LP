
package aplicação;

import java.util.ArrayList;


public class Operacoes {
    
    //adicionando uma tarefa(t) na lista
    public boolean adicionar(Tarefa t, ArrayList<Tarefa> lista){
        return lista.add(t);
        
    }
    
    //deletando uma tarefa (t) da lista
    public boolean deletar(Tarefa t, ArrayList<Tarefa> lista){
        
        return true;
        
    }
    
    //editando uma tarefa (t) do indice (i) da lista
    public boolean editar(Tarefa t,int id, ArrayList<Tarefa> lista){
        boolean editado = false;
        //loop de incremento da lista
        for (int j = 0; j < lista.size(); j++) {
            //comparando se o id da tarefa a ser editada existe na lista
            if(lista.get(j).getId() == id){
                lista.set(j, t);//edita
                editado = true;//troca o valor de editado p true
                break; //sai do loop
            }//fechamento do if
        }//fechamento do for
        return editado;
    }//fechamento do editar
}//fechamento de operaçoes
