
package herança;


public class DemoAuto {

    
    public static void main(String[] args) {
        
        Automovel auto = new Automovel("fusca", "azul", 1);
        System.out.println("O preço do" + auto.modelo + "é de R$" + auto.quantoCusta());
        
        AutomovelBasico autoB = new AutomovelBasico("ferrari", "vermelho", 2);
        System.out.println("O preço do " + autoB.modelo + "é de R$" + auto.quantoCusta());
        
        AutomovelBasico autoB2 = new AutomovelBasico(true, false,false, "audi", "preto",1);
        System.out.println("O preço do" + autoB2.modelo + "é de R$" + autoB2.quantoCusta());
        
        AutomovelLuxo autoL = new AutomovelLuxo(true,true,true,true,true,true, "mclaren", "laranja", 1);
        System.out.println("O preço do" + autoL.modelo + "é de R$" + autoL.quantoCusta());
        

    }
    
}
