
package herança;

import javax.swing.JOptionPane;


public class EstoqueDeAutomovel extends javax.swing.JFrame {

    
    public EstoqueDeAutomovel() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCheckBox1 = new javax.swing.JCheckBox();
        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        MODELO = new javax.swing.JComboBox<>();
        COR = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        GASOLINA = new javax.swing.JRadioButton();
        DIESEL = new javax.swing.JRadioButton();
        ALCOOL = new javax.swing.JRadioButton();
        GAS = new javax.swing.JRadioButton();
        jLabel3 = new javax.swing.JLabel();
        RP = new javax.swing.JCheckBox();
        LT = new javax.swing.JCheckBox();
        RD = new javax.swing.JCheckBox();
        DH = new javax.swing.JCheckBox();
        TE = new javax.swing.JCheckBox();
        CA = new javax.swing.JCheckBox();
        CT = new javax.swing.JButton();

        jCheckBox1.setText("jCheckBox1");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Concenssionaria de Automoveis");

        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 24)); // NOI18N
        jLabel1.setText("Monte seu carro e os opcionais");

        MODELO.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECIONE O AUTOMOVEL", "Audi", "Ferrari", "BMW", "McLauren" }));

        COR.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "SELECIONE A COR", "Vermelho", "Azul", "Preto", "Laranja" }));

        jLabel2.setText("TIPO DE COMBUSTIVEL");

        buttonGroup1.add(GASOLINA);
        GASOLINA.setText("GASOLINA");

        buttonGroup1.add(DIESEL);
        DIESEL.setText("DIESEL");

        buttonGroup1.add(ALCOOL);
        ALCOOL.setText("ALCOOL");

        buttonGroup1.add(GAS);
        GAS.setText("GAS");

        jLabel3.setText("OPCIONAIS");

        RP.setText("RETROVISOR PASSAGEIRO");

        LT.setText("LIMPADOR TRASEIRO");

        RD.setText("RADIO");

        DH.setText("DIREÇÃO HIDRAÚLICA");

        TE.setText("TRAVAS ELETRICAS");

        CA.setText("CAMBIO AUTOMATICO");

        CT.setText("CALCULAR TOTAL");
        CT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(141, 141, 141))
            .addGroup(layout.createSequentialGroup()
                .addGap(78, 78, 78)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(46, 46, 46)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(LT)
                            .addComponent(RP)
                            .addComponent(RD)
                            .addComponent(DH)
                            .addComponent(TE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(CA)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(CT)))
                        .addGap(171, 171, 171))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(MODELO, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(COR, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(42, 42, 42)
                                .addComponent(GASOLINA)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(DIESEL)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(ALCOOL)
                                .addGap(18, 18, 18)
                                .addComponent(GAS)))
                        .addGap(112, 155, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addComponent(jLabel1)
                .addGap(40, 40, 40)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(MODELO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(COR, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(GASOLINA)
                    .addComponent(DIESEL)
                    .addComponent(ALCOOL)
                    .addComponent(GAS))
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(RP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(LT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(RD)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(DH)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(TE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CA)
                    .addComponent(CT))
                .addContainerGap(50, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void CTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CTActionPerformed

            String mod = (String)MODELO.getSelectedItem();
            String cr = (String)COR.getSelectedItem();
            int tipo = 0;
            //double preço = 0;
            boolean retro = false,limpa = false,radio = false,dir = false,trava = false,cambio = false;
            
            if (GASOLINA.isSelected()){
                tipo = 1;
            }
            if (DIESEL.isSelected()){
                tipo = 2;
            }
            if (ALCOOL.isSelected()){
                tipo= 3;
            }
            if (GAS.isSelected()){
                tipo = 4;
            }
            
            if(RP.isSelected()){
                retro = true;
            }
            if(LT.isSelected()){
                limpa = true;
            }
            if(RD.isSelected()){
                radio = true;
            }
            if(DH.isSelected()){
                dir = true;
            }
            if(TE.isSelected()){
                trava = true;
            }
            if(CA.isSelected()){
                cambio = true;
            }
            
            AutomovelLuxo auto = new AutomovelLuxo(dir,cambio,trava,retro,limpa,radio,mod, cr,tipo);
            JOptionPane.showMessageDialog(rootPane, auto.quantoCusta());
            
    }//GEN-LAST:event_CTActionPerformed

    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EstoqueDeAutomovel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JRadioButton ALCOOL;
    private javax.swing.JCheckBox CA;
    private javax.swing.JComboBox<String> COR;
    private javax.swing.JButton CT;
    private javax.swing.JCheckBox DH;
    private javax.swing.JRadioButton DIESEL;
    private javax.swing.JRadioButton GAS;
    private javax.swing.JRadioButton GASOLINA;
    private javax.swing.JCheckBox LT;
    private javax.swing.JComboBox<String> MODELO;
    private javax.swing.JCheckBox RD;
    private javax.swing.JCheckBox RP;
    private javax.swing.JCheckBox TE;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
