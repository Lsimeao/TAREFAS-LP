
package herança;

public class Automovel {
    
    String modelo, cor;
    int tipoDeCombustivel;

    public Automovel(String modelo, String cor, int tipoDeCombustivel) {
        this.modelo = modelo;
        this.cor = cor;
        this.tipoDeCombustivel = tipoDeCombustivel;
    }
    
    public double quantoCusta(){
        double preço = 0.0;
        switch (tipoDeCombustivel) {
            case 1 -> preço = 20000;
            case 2 -> preço = 19520;
            case 3 -> preço = 25000;
            case 4 -> preço = 22000;
            default -> {
            }
        }
        return preço;
    }   
}
