package aplicação;

import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class TelaDeCadastro extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TelaDeCadastro.class.getName());
    int id;
    ArrayList<Tarefa> listaTask = new ArrayList<>();
    DefaultTableModel dtm; // tabela 

    public TelaDeCadastro() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtTITULO = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtDATA = new javax.swing.JFormattedTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        textDESCRICAO = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        cmbNIVEL = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTASK = new javax.swing.JTable();
        btADD = new javax.swing.JButton();
        btDEL = new javax.swing.JButton();
        btEDIT = new javax.swing.JButton();
        btCLEAR = new javax.swing.JButton();
        btCLOSE = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CADASTRO DE TAREFAS");

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(null));

        jLabel1.setText("TÍTULO");

        jLabel2.setText("ENTREGA");

        jLabel3.setText("DESCRIÇÃO");

        textDESCRICAO.setColumns(20);
        textDESCRICAO.setRows(5);
        jScrollPane2.setViewportView(textDESCRICAO);

        jLabel4.setText("NÍVEL");

        cmbNIVEL.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Fácil", "Intermediário", "Difícil", " " }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(61, 61, 61)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(jLabel2)
                        .addComponent(jLabel1))
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDATA, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtTITULO, javax.swing.GroupLayout.PREFERRED_SIZE, 425, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4)
                        .addGap(18, 18, 18)
                        .addComponent(cmbNIVEL, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(txtTITULO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cmbNIVEL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4))))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtDATA, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(127, Short.MAX_VALUE))
        );

        tblTASK.setBorder(javax.swing.BorderFactory.createLineBorder(null));
        tblTASK.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "ID", "TITULO", "DESCRIÇÃO", "NIVEL", "DATA LIMITE"
            }
        ));
        tblTASK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTASKMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblTASK);

        btADD.setText("ADD");
        btADD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btADDActionPerformed(evt);
            }
        });

        btDEL.setText("DEL");
        btDEL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDELActionPerformed(evt);
            }
        });

        btEDIT.setText("EDIT");
        btEDIT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEDITActionPerformed(evt);
            }
        });

        btCLEAR.setText("CLEAR");
        btCLEAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCLEARActionPerformed(evt);
            }
        });

        btCLOSE.setText("CLOSE");
        btCLOSE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCLOSEActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(197, Short.MAX_VALUE)
                .addComponent(btADD)
                .addGap(49, 49, 49)
                .addComponent(btDEL)
                .addGap(66, 66, 66)
                .addComponent(btEDIT)
                .addGap(58, 58, 58)
                .addComponent(btCLEAR)
                .addGap(67, 67, 67)
                .addComponent(btCLOSE)
                .addGap(222, 222, 222))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btADD)
                    .addComponent(btDEL)
                    .addComponent(btEDIT)
                    .addComponent(btCLEAR)
                    .addComponent(btCLOSE))
                .addContainerGap(11, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btCLOSEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCLOSEActionPerformed
        System.exit(0);//comando para encerrar o programa
    }//GEN-LAST:event_btCLOSEActionPerformed

    private void btCLEARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCLEARActionPerformed
        limpar();

    }//GEN-LAST:event_btCLEARActionPerformed
    private void limpar() {
        txtTITULO.setText("");
        txtDATA.setText("");
        cmbNIVEL.setSelectedIndex(0);
        textDESCRICAO.setText("");
    }

    //metodo p/ exibir as tarefas adicionadas na lista
    private void showTask() {
        dtm = (DefaultTableModel) tblTASK.getModel();
        dtm.setNumRows(0);
        for (int i = 0; i < listaTask.size(); i++) {
            dtm.addRow(new Object[]{
                listaTask.get(i).getId(),
                listaTask.get(i).getTitulo(),
                listaTask.get(i).getDescricao(),
                listaTask.get(i).getNivel(),
                listaTask.get(i).getDataLimite()
            });

        }
    }

    private void btADDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btADDActionPerformed
        String tit, dta, desc;
        //capturando as informações do usuário
        tit = txtTITULO.getText();
        dta = txtDATA.getText();
        int niv = cmbNIVEL.getSelectedIndex();
        desc = textDESCRICAO.getText();
        //criando a tarefa (objeto tarefa)
        Tarefa t = new Tarefa(tit, desc, dta, ++id, niv);
        //objeto operacoes
        Operacoes op = new Operacoes();

        if (op.adicionar(t, listaTask)) {
            //JOptionPane.showMessageDialog(rootPane, "Sucesso!");
            showTask();
            limpar();

        } else {
            JOptionPane.showMessageDialog(rootPane, "Falha!");
        }


    }//GEN-LAST:event_btADDActionPerformed

    private void tblTASKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTASKMouseClicked
        // seleciona a linha da tabela que o usuário clicou
        if (tblTASK.getSelectedRow() != -1) {
            txtTITULO.setText(tblTASK.getValueAt(tblTASK.getSelectedRow(), 1).toString());
            txtDATA.setText(tblTASK.getValueAt(tblTASK.getSelectedRow(), 4).toString());
            textDESCRICAO.setText(tblTASK.getValueAt(tblTASK.getSelectedRow(), 2).toString());
            cmbNIVEL.setSelectedIndex((int) tblTASK.getValueAt(tblTASK.getSelectedRow(), 3));

        }

    }//GEN-LAST:event_tblTASKMouseClicked

    private void btEDITActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEDITActionPerformed
        if (tblTASK.getSelectedRow() != -1) {
            String tit, dta, desc;
            //capturando as informações do usuário
            tit = txtTITULO.getText();
            dta = txtDATA.getText();
            int niv = cmbNIVEL.getSelectedIndex();
            desc = textDESCRICAO.getText();
            int idTask = (int) tblTASK.getValueAt(tblTASK.getSelectedRow(), 0);
            Tarefa t = new Tarefa(tit, desc, dta, idTask, niv);
            Operacoes op = new Operacoes();
            if (op.editar(t, idTask, listaTask)) {
                showTask();
                limpar();

            } else {
                JOptionPane.showMessageDialog(rootPane, "Falha na edição. Tente novamente.");
            }

        } else {
            JOptionPane.showMessageDialog(rootPane, "clique na linha que deseja editar.");
        }
    }//GEN-LAST:event_btEDITActionPerformed

    private void btDELActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDELActionPerformed
        if (tblTASK.getSelectedRow() != -1){
            int idTarefa = (int) tblTASK.getValueAt(tblTASK.getSelectedRow(), 0);
            Operacoes op = new Operacoes();

            if (op.deletar(idTarefa, listaTask)) {
                    dtm.removeRow(tblTASK.getSelectedRow());

            } else {
                JOptionPane.showMessageDialog(rootPane, "erro ao excluir tarefa!");
            }
        }else{
            JOptionPane.showMessageDialog(rootPane, "é preciso clicar em uma tarefa");
        }
    }//GEN-LAST:event_btDELActionPerformed

    public static void main(String args[]) {
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(() -> new TelaDeCadastro().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btADD;
    private javax.swing.JButton btCLEAR;
    private javax.swing.JButton btCLOSE;
    private javax.swing.JButton btDEL;
    private javax.swing.JButton btEDIT;
    private javax.swing.JComboBox<String> cmbNIVEL;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable tblTASK;
    private javax.swing.JTextArea textDESCRICAO;
    private javax.swing.JFormattedTextField txtDATA;
    private javax.swing.JTextField txtTITULO;
    // End of variables declaration//GEN-END:variables
}
