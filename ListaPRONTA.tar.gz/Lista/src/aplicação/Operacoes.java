
package aplicação;

import java.util.ArrayList;


public class Operacoes {
    
    //adicionando uma tarefa(t) na lista
    public boolean adicionar(Tarefa t, ArrayList<Tarefa> lista){
        return lista.add(t);
        
    }
    
    //deletando uma tarefa (t) da lista
    public boolean deletar(int n, ArrayList<Tarefa> lista){
        boolean  deletado = false;
        for (int i = 0; i < lista.size(); i++) {
            if(lista.get(i).getId()== n){
                lista.remove(i);
                deletado = true;
                break;
            }
        }
        return deletado;
    }
    
    //editando uma tarefa (t) do indice (i) da lista
    public boolean editar(Tarefa t,int id, ArrayList<Tarefa> lista){
        boolean editado = false;
        for (int j = 0; j < lista.size(); j++) {
            //comparando se o id da tarefa a ser editado existe na lista
            if(lista.get(j).getId() == id){
                lista.set(j, t);
                editado = true;
                break;
            }
        }
        return editado;
 
    }
    
}
