
package bancosolidario;

import java.util.Scanner;


public class Principal {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        Correntista c1 = new Correntista(1234, "Lara", 1000);
        int op = 0;    
        while(op!=4){
            System.out.println("Meno de operações");
            System.out.println("1.depositar:");
            System.out.println("2.retirar:");
            System.out.println("3.saldo:");
            System.out.println("4.sair:");
            op = sc.nextInt();
            
            switch (op){
                case 1:
                    System.out.println("Informe o valor a ser depositado: ");
                    double valor = sc.nextDouble();
                    double valorAtual = c1.getSaldo() + valor;
                    c1.setSaldo(valorAtual);
                    break;
                case 2:
                    System.out.println("Iforme o valor a ser retirado: ");
                    double valor2 = sc.nextDouble();
                    double valorRetirado = c1.getSaldo() - valor2;
                    c1.setSaldo(valorRetirado);
                    
                    break;
                case 3:
                    System.out.println("Você escolheu ver o seu saldo: ");
                    System.out.println(c1.toString());
                    break;
                case 4:
                    System.out.println("saindo...");
                    System.exit(0);
                    
                    
            }
    
    }
        
        
    }
    
}
