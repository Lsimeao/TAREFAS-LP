
package javabd;
import java.sql.*;

public class Transacoes {
    public void inserir(OrdemServico os){
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement("insert into ordem_servico (num_os, descricao, tipo) values()");
            
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro");
        }
    }
}
