
package livraria;

public class Livraria {
    private String desc_lvr, nm_lvr, gen_lvr;
    
    public Livraria(){
        
    }

    public Livraria(String desc_lvr, String nm_lvr, String gen_lvr) {
        this.desc_lvr = desc_lvr;
        this.nm_lvr = nm_lvr;
        this.gen_lvr = gen_lvr;
    }

    public String getDesc_lvr() {
        return desc_lvr;
    }

    public void setDesc_lvr(String desc_lvr) {
        this.desc_lvr = desc_lvr;
    }

    public String getNm_lvr() {
        return nm_lvr;
    }

    public void setNm_lvr(String nm_lvr) {
        this.nm_lvr = nm_lvr;
    }

    public String getGen_lvr() {
        return gen_lvr;
    }

    public void setGen_lvr(String gen_lvr) {
        this.gen_lvr = gen_lvr;
    }

    @Override
    public String toString() {
        return "Livraria{" + "desc_lvr=" + desc_lvr + ", nm_lvr=" + nm_lvr + ", gen_lvr=" + gen_lvr + '}';
    }
        
    
    }
    

