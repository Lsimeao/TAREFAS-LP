
package livraria;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class Transacoes {
    public ArrayList<Livraria> consultar (String nm){        
        Connection con = Conexao.conecta();//banco
        PreparedStatement stmt = null; //tabela
        ResultSet rs = null;  //registros da tabela
        
        ArrayList<Livraria> linha = new ArrayList<>();
        try {
            stmt = con.prepareStatement("select * from livraria where nm_lvr = '"+nm+"'");
            rs = stmt.executeQuery();
            if (rs.next()){
                Livraria lvr = new Livraria();
                
                lvr.setDesc_lvr(rs.getString("desc_lvr"));
                lvr.setNm_lvr(rs.getString("nm_lvr"));
                lvr.setGen_lvr(rs.getString("gen_lvr"));
                linha.add(lvr);
                
            }
            
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null,"Falha ao consultar resgistro/n" + e);
        } finally {
            Conexao.fechaConexao(con,stmt,rs);
        }
        return linha; 
    }
    
    public void inserir(Livraria lvr){
        
        Connection con = Conexao.conecta();
        PreparedStatement stmt = null;
        try {
            stmt = con.prepareStatement("insert into livraria "
                    + "(desc_lvr, nm_lvr, gen_lvr) values (?,?,?)");
            
            stmt.setString(1, lvr.getDesc_lvr());
            stmt.setString(3, lvr.getGen_lvr());
            stmt.setString(2, lvr.getNm_lvr());
            stmt.executeUpdate();
            JOptionPane.showMessageDialog(null,
                    lvr.getNm_lvr() + " inserida com sucesso!");           
        } catch (SQLException e) {
            System.out.println("Falha ao inserir registro" + e);
        }finally{
            Conexao.fechaConexao(con, stmt);
        }
        
    }//fechamento do método  
    
    public int deletar(String nome){
    Connection con = Conexao.conecta();//banco
    PreparedStatement stmt = null; //tabela
    int rs = 0;
        try {
            stmt = con.prepareStatement("delete from livraria where nm_lvr = '"+nome+"'");
            rs = stmt.executeUpdate();
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"erro ao deletar" + e);
        
        }finally{
            Conexao.fechaConexao(con, stmt);
        }
        
        return rs;
    }
    
    
}//fechamneot da classe

    
    
    
    

