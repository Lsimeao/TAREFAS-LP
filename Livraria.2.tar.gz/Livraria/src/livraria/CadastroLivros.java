
package livraria;
import java.util.ArrayList;
import javax.swing.JOptionPane;


public class CadastroLivros extends javax.swing.JFrame {
 
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(CadastroLivros.class.getName());

    public CadastroLivros() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jSpinner1 = new javax.swing.JSpinner();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNome = new javax.swing.JTextField();
        txtGenero = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtDesc = new javax.swing.JTextArea();
        btCad = new javax.swing.JButton();
        btConsult = new javax.swing.JButton();
        btClear = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        btDELETE = new javax.swing.JButton();

        jTextField1.setText("jTextField1");

        jTextField2.setText("jTextField2");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        jLabel1.setText("Nome Do Livro");

        jLabel2.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        jLabel2.setText("Gênero Do Livro");

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Noto Sans", 2, 14)); // NOI18N
        jLabel3.setText("Descriçaõ");

        txtDesc.setColumns(20);
        txtDesc.setRows(5);
        jScrollPane1.setViewportView(txtDesc);

        btCad.setText("CADASTRAR");
        btCad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCadActionPerformed(evt);
            }
        });

        btConsult.setText("CONSULTAR");
        btConsult.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btConsultActionPerformed(evt);
            }
        });

        btClear.setText("LIMPAR");
        btClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btClearActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Noto Sans", 3, 24)); // NOI18N
        jLabel4.setText("Cadastrar Livros");

        btDELETE.setText("DELETAR");
        btDELETE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDELETEActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btCad)
                                .addGap(27, 27, 27)
                                .addComponent(btConsult)
                                .addGap(26, 26, 26)
                                .addComponent(btClear)
                                .addGap(36, 36, 36)
                                .addComponent(btDELETE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel1)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3))
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtNome)
                                    .addComponent(txtGenero)
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 320, Short.MAX_VALUE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(237, 237, 237)
                        .addComponent(jLabel4)))
                .addContainerGap(148, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(54, 54, 54)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtGenero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btCad)
                    .addComponent(btConsult)
                    .addComponent(btClear)
                    .addComponent(btDELETE))
                .addGap(72, 72, 72))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
            // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btCadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCadActionPerformed

             
       Livraria lvr = new Livraria();
       Transacoes tr = new Transacoes();
       
       String gr = txtGenero.getText();
       String ds = txtDesc.getText();
       String nm = txtNome.getText();

       lvr.setDesc_lvr(ds);
       lvr.setGen_lvr(gr);
       lvr.setNm_lvr(nm);
       
       tr.inserir(lvr);
       btClearActionPerformed(evt);
        
        
        // TODO add your handling code here:
    }//GEN-LAST:event_btCadActionPerformed

    private void btClearActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btClearActionPerformed
        limparCampos();
        // TODO add your handling code here:
    }//GEN-LAST:event_btClearActionPerformed

    private void btConsultActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btConsultActionPerformed
       Livraria lvr = new Livraria();
       Transacoes tr = new Transacoes();
       String nm = txtNome.getText();

       ArrayList<Livraria> resultado = tr.consultar(nm);
       
        try {
            txtNome.setText(String.valueOf(resultado.get(0).getNm_lvr()));
            txtGenero.setText(String.valueOf(resultado.get(0).getGen_lvr()));
            txtDesc.setText(String.valueOf(resultado.get(0).getDesc_lvr()));
            
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Não encontrada\n" +e);
        }
       

        // TODO add your handling code here:
    }//GEN-LAST:event_btConsultActionPerformed

    private void btDELETEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDELETEActionPerformed
        String nome = txtNome.getText();
        Transacoes tr = new Transacoes();
        if(tr.deletar(nome)!=0){
            JOptionPane.showMessageDialog(null,"excluido com sucesso");
            limparCampos();
        }else{
            JOptionPane.showMessageDialog(null,"erro ao excluir");
        }

    }//GEN-LAST:event_btDELETEActionPerformed

    private void limparCampos(){
            txtNome.setText("");
            txtGenero.setText("");
            txtDesc.setText("");
    
        }
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(() -> new CadastroLivros().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btCad;
    private javax.swing.JButton btClear;
    private javax.swing.JButton btConsult;
    private javax.swing.JButton btDELETE;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSpinner jSpinner1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextArea txtDesc;
    private javax.swing.JTextField txtGenero;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
