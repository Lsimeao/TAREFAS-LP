
package socketudp;
import java.net.*;

public class Servidor {
    
    public static void main(String[] args) {
        try {
            DatagramSocket ds = new DatagramSocket(8080);
            System.out.println("Servidor executando na porta 8080 ");
            
            byte[] recDados = new byte[512];
            byte[] envDados = new byte[512];
            
            DatagramPacket dpRD = new DatagramPacket(recDados,recDados.length);
            ds.receive(dpRD);//recebendo os dados que vieram do cliente 
            
            String msg = new String(dpRD.getData());//conteudo da msg
            InetAddress ip = dpRD.getAddress();//enedereço ip da maquina que enviou a msg
            int port = dpRD.getPort();
            
            System.out.println("Mensagem do cliente " +msg);
            System.out.println("Endereço IP............: " +ip.toString());
            System.out.println("Porta...........: " +port);
            
            envDados = msg.toUpperCase().getBytes();//msg do servidor para o cliente
            DatagramPacket dpED = new DatagramPacket(envDados,envDados.length, ip, port);//montando pacote para envio de dados
            ds.send(dpED);
            
            
        } catch (Exception e) {
            System.out.println("Exceção: " +e);
        }
        
    }//fechamento do main
    
}//fechamento da classe servidor
