package socketudp;

import java.net.*;

public class TelaCliente extends javax.swing.JFrame {

    DatagramSocket ds;
    DatagramPacket dp;
   // int port = 8080;
    byte[] recDados;
    byte[] envDados;
    InetAddress endIp;

    public TelaCliente() {
        initComponents();
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        Area = new javax.swing.JTextArea();
        btEnviar = new javax.swing.JButton();
        txtMSG = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Area.setColumns(20);
        Area.setRows(5);
        jScrollPane1.setViewportView(Area);

        btEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btEnviarActionPerformed(evt);
            }
        });

        txtMSG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMSGActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Noto Sans", 1, 24)); // NOI18N
        jLabel1.setText("CLIENTE");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(110, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtMSG)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btEnviar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(103, 103, 103))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(247, 247, 247))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btEnviar, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMSG, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(43, 43, 43))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtMSGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMSGActionPerformed
    }//GEN-LAST:event_txtMSGActionPerformed

    private void btEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btEnviarActionPerformed
        try {
            String Msg = txtMSG.getText();
            envDados = Msg.getBytes();
            System.out.println("Vai para o servidor");
            dp = new DatagramPacket(envDados, envDados.length, endIp, 8080);
            ds.send(dp);
            Area.append( Msg + "\n");
            btEnviar.setText("");

        } catch (Exception e) {
            Area.append("Erro ao enviar a mensagem" + e + "/n");
        }
    }

    public void executar() {
        try {
            //envDados = new byte[64];
            recDados = new byte[64];
            ds = new DatagramSocket();
            endIp = InetAddress.getByName("localhost");
            Area.append("Cliente iniciado\n");
            while(true){
                dp = new DatagramPacket(recDados, recDados.length);
                ds.receive(dp);
                String msgDoServidor = new String(dp.getData());
                System.out.println("Veio do servidor " + msgDoServidor);
                Area.append(msgDoServidor + "\n");
                endIp = dp.getAddress();
                //port = dp.getPort();
                
            }
            
            
        } catch (Exception e) {
            Area.append("Erro" + e + "\n");
            
        }


    }//GEN-LAST:event_btEnviarActionPerformed

    public static void main(String args[]) {
        TelaCliente tc = new TelaCliente();
        tc.setVisible(true);
        tc.executar();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextArea Area;
    private javax.swing.JButton btEnviar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField txtMSG;
    // End of variables declaration//GEN-END:variables
}
