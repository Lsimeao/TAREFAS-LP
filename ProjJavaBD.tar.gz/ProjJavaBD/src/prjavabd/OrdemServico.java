package prjavabd;

public class OrdemServico {
    private int numOS;
    private String desc, status;

    public OrdemServico() {
    }

    public OrdemServico(int numOS, String desc, String status) {
        this.numOS = numOS;
        this.desc = desc;
        this.status = status;
    }

    public int getNumOS() {
        return numOS;
    }

    public void setNumOS(int numOS) {
        this.numOS = numOS;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    
    


}
