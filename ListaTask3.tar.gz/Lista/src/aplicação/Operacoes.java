
package aplicação;

import java.util.ArrayList;


public class Operacoes {
    
    //adicionando uma tarefa(t) na lista
    public boolean adicionar(Tarefa t, ArrayList<Tarefa> lista){
        return lista.add(t);
        
    }
    
    //deletando uma tarefa (t) da lista
    public boolean deletar(Tarefa t, ArrayList<Tarefa> lista){
        
        return true;
        
    }
    
    //editando uma tarefa (t) do indice (i) da lista
    public boolean editar(Tarefa t,int i, ArrayList<Tarefa> lista){
        
        return true;
        
    }
}
