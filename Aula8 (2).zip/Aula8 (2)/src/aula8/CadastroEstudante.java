package aula8;

import javax.swing.JOptionPane;

public class CadastroEstudante extends javax.swing.JFrame {

    int cont;
    Estudante[] est = new Estudante[3];

    public CadastroEstudante() {
        initComponents();
        for (int i = 0; i < 3; i++) {
            Estudante et = new Estudante("", "", "");
            est[i] = et;

        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtMat = new javax.swing.JTextField();
        txtNome = new javax.swing.JTextField();
        txtEMAIL = new javax.swing.JTextField();
        btCAD = new javax.swing.JButton();
        btPESQ = new javax.swing.JButton();
        btDEL = new javax.swing.JButton();
        btALT = new javax.swing.JButton();
        Limpar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("CADASTRO DE ESTUDANTE");

        jLabel1.setFont(new java.awt.Font("DejaVu Sans", 3, 24)); // NOI18N
        jLabel1.setText("DADOS DO ESTUDANTE");

        jLabel2.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        jLabel2.setText("MATRÍCULA:");

        jLabel3.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        jLabel3.setText("NOME:");

        jLabel4.setFont(new java.awt.Font("DejaVu Sans", 1, 14)); // NOI18N
        jLabel4.setText("EMAIL:");

        txtNome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtNomeActionPerformed(evt);
            }
        });

        btCAD.setText("CADASTRAR");
        btCAD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCADActionPerformed(evt);
            }
        });

        btPESQ.setText("CONSULTAR");
        btPESQ.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPESQActionPerformed(evt);
            }
        });

        btDEL.setText("DELETAR");
        btDEL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDELActionPerformed(evt);
            }
        });

        btALT.setText("ALTERAR");

        Limpar.setText("LIMPAR");
        Limpar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LimparActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel1)
                        .addGap(165, 165, 165))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(178, 178, 178)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel3)
                                        .addComponent(jLabel2))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(45, 45, 45)
                                        .addComponent(jLabel4)))
                                .addGap(28, 28, 28)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtEMAIL, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(303, 303, 303)
                                .addComponent(txtMat, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addGap(147, 147, 147)
                                .addComponent(btCAD)
                                .addGap(18, 18, 18)
                                .addComponent(btPESQ)
                                .addGap(18, 18, 18)
                                .addComponent(btDEL)
                                .addGap(18, 18, 18)
                                .addComponent(btALT)
                                .addGap(18, 18, 18)
                                .addComponent(Limpar)))
                        .addGap(0, 25, Short.MAX_VALUE)))
                .addGap(75, 75, 75))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addComponent(jLabel1)
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtMat, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtNome, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(txtEMAIL, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btCAD)
                    .addComponent(btPESQ)
                    .addComponent(btDEL)
                    .addComponent(btALT)
                    .addComponent(Limpar))
                .addContainerGap(72, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtNomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNomeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNomeActionPerformed

    private void btDELActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDELActionPerformed

        String mat = txtMat.getText(); //capturando a matricula
        boolean achou = false;
        for (int i = 0; i < 3; i++) {
            if(mat.equals(est[i].getMat())){
                int resp = JOptionPane.showConfirmDialog(rootPane, "Tem certeza que deseja deletar?");
                if (resp==0){
                  achou = true;
                  Estudante et = new Estudante("","","");
                  est[i] = et;
                  limparCampo();
                  cont--;
                  break;
                }//fim do if da respp
                
            }//fim do if da comparação da matricula
            
            
        }//fim do for
    
        
    }//GEN-LAST:event_btDELActionPerformed

    private void btCADActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCADActionPerformed
        //capturando as informaçoes digitadas pelo usuario
        String mat = txtMat.getText();
        String nome = txtNome.getText();
        String email = txtEMAIL.getText();

        if (cont < 3) {
            if (!txtNome.getText().isBlank() && !txtMat.getText().isBlank() && !txtEMAIL.getText().isBlank()) {

                //et objeto do estudante
                Estudante et = new Estudante(mat, nome, email);
                //adicionando o objeto et de estudante da lista
                est[cont] = et;
                cont++;
                JOptionPane.showMessageDialog(rootPane, "Estudante cadastrado com sucesso");
                limparCampo();
            } else {
                JOptionPane.showInternalMessageDialog(rootPane, "Matrícula, nome e e-mail são obrigatórios");

            }
        } else {
            JOptionPane.showMessageDialog(rootPane, "Lista cheia.\n Tente novamente");
        }
    }//GEN-LAST:event_btCADActionPerformed

    private void LimparActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LimparActionPerformed
    }//GEN-LAST:event_LimparActionPerformed

    private void btPESQActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPESQActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btPESQActionPerformed

    private void limparCampo() {
        txtMat.setText("");
        txtNome.setText("");
        txtEMAIL.setText("");
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CadastroEstudante().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Limpar;
    private javax.swing.JButton btALT;
    private javax.swing.JButton btCAD;
    private javax.swing.JButton btDEL;
    private javax.swing.JButton btPESQ;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField txtEMAIL;
    private javax.swing.JTextField txtMat;
    private javax.swing.JTextField txtNome;
    // End of variables declaration//GEN-END:variables
}
