
package escola;


public class Principal {

   
    public static void main(String[] args) {
        
        Professor p1 = new Professor("roberta", "informatica");
        
        System.out.println(p1.toString());
        
        //System.out.println(p1.getNome().toUpperCase() + " vc vai dar aula hj?");
        
        Aluno a1 = new Aluno("lara", 12345);
        
        System.out.println(a1.toString());
        
        //System.out.println(a1.getNome().toUpperCase() + " vc vem pra aula hj?");

        
       
    }
    
}
