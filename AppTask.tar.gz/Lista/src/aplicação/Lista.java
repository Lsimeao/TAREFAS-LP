package aplicação;


public class Lista {

   
    public static void main(String[] args) {
        
        
        String[] diasDaSemana1 = {"dom","seg","ter","qua","qui","sex","sab"};
        
        String[] diasDaSemana2 = new String[7];
        for (int i = 0; i < diasDaSemana1.length; i++) {System.out.println(diasDaSemana1[i]);
            
        }
        
        for (String nome : diasDaSemana2) { System.out.println(nome);
            
        }
        }
    }
    
