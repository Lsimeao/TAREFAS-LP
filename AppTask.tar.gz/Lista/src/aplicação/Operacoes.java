
package aplicação;


public class Operacoes {
    
}
